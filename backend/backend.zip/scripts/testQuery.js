const db = require('../config/db');

async function testQuery() {
  try {
    const [rows] = await db.query(
      'SELECT * FROM job_openings WHERE is_active = true ORDER BY created_at DESC'
    );
    console.log('Jobs returned from query:', rows.length);
    console.log(rows);
    process.exit(0);
  } catch (error) {
    console.error('Error:', error);
    process.exit(1);
  }
}

testQuery();
